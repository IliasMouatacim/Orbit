Orbit Chat for Windows 10/11 (x64)
Extract all files into one folder and open orbit-chat.exe. Keep WebView2Loader.dll beside it.
Requires Internet access and Microsoft Edge WebView2 Runtime.
